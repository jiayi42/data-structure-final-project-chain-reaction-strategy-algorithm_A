#include <iostream>
#include <stdlib.h>
#include <time.h>
#define MAX 1594871214
using namespace std;

/******************************************************
 * In your algorithm, you can just use the the funcitons
 * listed by TA to get the board information.(functions 
 * 1. ~ 4. are listed in next block)
 * 
 * The STL library functions is not allowed to use.
******************************************************/
//#include "../include/board.h"
#include "../include/rules.h"
 ///////////////////////////////////////////////////////////////
template <class T>
class stack{
    private:
        struct Node{
            T data;
            Node* next_node;
            Node(T data = NULL):data(data){}
            Node(T data, Node* next):data(data),next_node(next){}
        };
        int stacksize;
        Node* topnode;
    public:
        stack(): stacksize(0),topnode(NULL){}
        void push(T element);
        int size();
        T top();
        bool Isempty();
        void pop();
};
template <class T> 
int stack<T>::size(){
    return this->stacksize;
}
template <class T> 
bool stack<T>::Isempty(){
    if(this->size() == 0)
        return true;
    return false;
}
template <class T> 
void stack<T>::push(T node){
    if(Isempty()){
        Node* newnode = new Node(node,NULL);
        this->topnode = newnode;
        this->stacksize++;
        return;
    }
    Node* newnode = new Node(node,topnode);
    topnode = newnode;  
    this->stacksize+=1;
}
template <class T> 
void stack<T>::pop() {
    if(Isempty()) return;
    Node* deletenode = topnode;
    topnode = topnode->next_node;
    delete deletenode;
    deletenode = NULL;
    stacksize-=1;
}
template <class T> 
T stack<T>::top(){
    if(Isempty())
        return 0;
    return topnode->data;
}

Board boarddeepcopy(Board board) {
    int num[ROW][COL];
    for(int i = 0; i < ROW; i++) for(int j = 0; j < COL; j++)num[i][j] = board.get_orbs_num(i,j);
    Board copyboard;
    for(int i = 0; i < ROW; i++) for(int j = 0; j < COL; j++) {
        Player* play = new Player(board.get_cell_color(i,j));
        for(int k = 0; k < num[i][j]; k++) {copyboard.place_orb(i, j, play);}
         delete play;
    }
    return copyboard;
}
int danger(Board board ,int a,int b){return 4-(board.get_capacity(a, b)-board.get_orbs_num(a, b));}
int row[4] = { -1, 0, 0, 1 };
int col[4] = { 0, -1, 1, 0 };

class position { 
    public: 
        position(); 
        int x;int y; 
        position(int i, int j):x(i),y(j){}
}; 

int potential(Board board,int color){
    ///////////////////////
    bool visit[ROW][COL];
        int cum[ROW][COL]={0};
    for(int i=0;i<ROW;i++)for(int j=0;j<COL;j++)visit[i][j]=false;

    for(int i=0;i<ROW;i++){
        for(int j=0;j<COL;j++){
            if(!visit[i][j] && board.get_cell_color(i,j)==color && danger( board ,i,j)==3 ){
                stack<position*> st;
                position* newNode = new position(i,j);
                st.push(newNode);
                while(!st.Isempty()){
                    position *currentnode;currentnode=st.top(); st.pop();
                    visit[currentnode->x][currentnode->y]=true;
                    cum[i][j]++;
                    for (int k = 0; k < 4; k++){
                        int x = i + row[k] ;
                        int y = j + col[k] ;
                        if (!index_range_illegal(x,y)){
                            if(!visit[x][y] && board.get_cell_color(x,y)==color && danger( board ,x,y)==3 ){
                                position* newNode = new position(x,y);
                                st.push(newNode);
                            }
                        }
                    }
                }  
            }
        }
    }
    int temp=0;
    for(int i=0;i<ROW;i++)for(int j=0;j<COL;j++)temp+=2*cum[i][j];

    return temp;

}
int fullpotential(Board board){

    bool visit[ROW][COL];
    int cum[ROW][COL]={0};
    for(int i=0;i<ROW;i++)for(int j=0;j<COL;j++)visit[i][j]=false;

    for(int i=0;i<ROW;i++){
        for(int j=0;j<COL;j++){
            if(!visit[i][j] && danger( board ,i,j)==3 ){
                stack<position*> st;
                position* newNode = new position(i,j);
                st.push(newNode);
                while(!st.Isempty()){
                    position *currentnode;currentnode=st.top(); st.pop();
                    visit[currentnode->x][currentnode->y]=true;
                    cum[i][j]++;
                    for (int k = 0; k < 4; k++){
                        int x = i + row[k] ;
                        int y = j + col[k] ;
                        if (!index_range_illegal(x,y)){
                            if(!visit[x][y] && danger( board ,x,y)==3 ){
                                position* newNode = new position(x,y);
                                st.push(newNode);
                            }
                        }
                    }
                }  
            }
        }
    }
    int temp=0;
    for(int i=0;i<ROW;i++)for(int j=0;j<COL;j++)temp+=2*cum[i][j];

    return temp;

}
int checkdanger(Board board,int colorOpponent,int i,int j){
    int temp=0;
    if(!index_range_illegal(i+1,j))if(board.get_cell_color(i+1,j)==colorOpponent && danger(board,i+1,j)==3)temp+=6-board.get_capacity(i, j);
    if(!index_range_illegal(i-1,j))if(board.get_cell_color(i-1,j)==colorOpponent && danger(board,i-1,j)==3)temp+=6-board.get_capacity(i, j);
    if(!index_range_illegal(i,j+1))if(board.get_cell_color(i,j+1)==colorOpponent && danger(board,i,j+1)==3)temp+=5-board.get_capacity(i, j);
    if(!index_range_illegal(i,j-1))if(board.get_cell_color(i,j-1)==colorOpponent && danger(board,i,j-1)==3)temp+=5-board.get_capacity(i, j);
    return temp;
}
bool nodangerscore(Board board,int i,int j){
    int temp=0;
    if(board.get_capacity(i, j)==2)temp+=3;
    if(board.get_capacity(i, j)==3)temp+=2;
    if(danger(board ,i,j)==3)temp*=2;
    return temp;
}

int BoardEvaluator(Board board, Player player,bool myturn) {
    char colorPlayer = player.get_color();
    char colorOpponent;
    if(colorPlayer == 'r')
        colorOpponent = 'b';
    else 
        colorOpponent = 'r';

    int orbPlayer = 0, orbOpponent = 0; int orbScore = 0;

    int temp=0;
    for(int i=0;i<ROW;i++){
        for(int j=0;j<COL;j++){
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            if(board.get_cell_color(i,j)==colorPlayer){
                bool invulnerable = true;
                orbPlayer+=board.get_orbs_num(i,j);
                temp=checkdanger(board,colorOpponent,i,j);
                if(temp>0){
                        orbScore-=checkdanger(board,colorOpponent,i,j);
                        invulnerable = false;
                }
                if(invulnerable)orbScore+=nodangerscore(board,i,j);
            }
            else if(board.get_cell_color(i,j)==colorOpponent){
                orbOpponent+=board.get_orbs_num(i,j);
            }
        }
    }
    orbScore+=orbPlayer;
    ////////////////////////////////////////////////////
    int boom=fullpotential( board);
    int pboom=potential( board,colorPlayer);
    int oboom=potential( board,colorOpponent);
    //int opboom=potential( board,color);
    if(orbPlayer>1 && orbOpponent==0) return 10000.0;
    //if(boom>=24 && color==colorPlayer)return 10000.0;
    if(orbPlayer==0 && orbOpponent>1) return -10000.0;

    ////////////////////////////////////////////////////////
    //if(boom>18 &&  potential( board,colorOpponent)<4 && color==colorPlayer)orbScore-=100;// do not keep enemy alive when it is dangerous
    //if(boom>=30 && pboom<16 && color==colorPlayer)orbScore+=20;
    //if(boom>30 && (oboom-pboom)>4 && color==colorOpponent)orbScore+=boom;
    //if(boom<20 && pboom>6 )orbScore-=pboom;
    if(orbOpponent<30){// enemy does not dominate the game
        if(myturn)orbScore-=oboom;//after I place, my Opponent has fewer chances to blow

        //else
        orbScore+=boom; //blow dominator
    }

    //if(boom>16)
    //orbScore-=oboom;
    ////////////////////////////////////////////////////////
    return orbScore;
}
int max (int a,int b) {return (a<b)?b:a;}
int min (int a,int b) {return (a>b)?b:a;}
int alpha_beta(Board board, int alpha,int beta,int depth, Player player, Player opponent, bool myturn) {
    int colorPlayer = player.get_color();
    int colorOpponent = opponent.get_color();
    int score = BoardEvaluator(board, player,myturn);
    if(score == 10000) return score;
    if(score == -10000) return score;
    if(depth == 2)return score;
    int best = -MAX;
    int worst= MAX;
    if(myturn) {
        best = -MAX; 
        for(int i = 0; i < ROW; i++) for(int j = 0; j < COL; j++) {
            if(board.get_cell_color(i,j) == colorPlayer || board.get_cell_color(i,j) == 'w') {
                if (beta <= alpha) break;     
                Board board_copy = boarddeepcopy(board);
                board_copy.place_orb(i,j,&player);
                best = max(best, alpha_beta(board_copy,alpha,beta, depth+1, player, opponent,false)); 
                alpha = max(alpha, best);     
            }
            if (beta <= alpha) break;
        }

        return best;
    }
    else {
        worst= MAX;
        for(int i = 0; i < ROW; i++) for(int j = 0; j < COL; j++) {
            if(board.get_cell_color(i,j) == colorOpponent || board.get_cell_color(i,j) == 'w') {
                 if (beta <= alpha) break; 
                Board board_copy = boarddeepcopy(board);
                board_copy.place_orb(i,j,&opponent);
                worst = min(worst, alpha_beta(board_copy,alpha, beta, depth+1, player, opponent,  true));
                beta = min(beta, worst);
                
            }
            if (beta <= alpha) break; 
        }

        return worst;
    }
}
position God_choose(Board board, Player player) {
    char colorPlayer = player.get_color();

    char colorOpponent;
    if(colorPlayer == 'r')
        colorOpponent = 'b';
    else 
        colorOpponent = 'r';

    Player opponent(colorOpponent); 

    int Best = -MAX;
    position choose(0,0);
    for(int i = 0; i < ROW; i++) for(int j = 0; j < COL; j++) 
        if(board.get_cell_color(i,j) == colorPlayer || board.get_cell_color(i,j) == 'w'){
            Board board_copy = boarddeepcopy(board);
            board_copy.place_orb(i,j,&player);
            int alpha = -MAX;
            int beta =  MAX;
            int depth = 0;
            int movescore = alpha_beta(board_copy,alpha,beta, depth, player ,opponent, false);
            if(movescore > Best) {
                Best = movescore;
                choose.x = i;
                choose.y = j;
            }
        }

    return choose;
}
////////////////////////////////////////////////////////////////////////////////
/*************************************************************************
 * 1. int board.get_orbs_num(int row_index, int col_index)
 * 2. int board.get_capacity(int row_index, int col_index)
 * 3. char board.get_cell_color(int row_index, int col_index)
 * 4. void board.print_current_board(int row_index, int col_index, int round)
 * 
 * 1. The function that return the number of orbs in cell(row, col)
 * 2. The function that return the orb capacity of the cell(row, col)
 * 3. The function that return the color fo the cell(row, col)
 * 4. The function that print out the current board statement
*************************************************************************/


void algorithm_A(Board board, Player player, int index[]){

    // cout << board.get_capacity(0, 0) << endl;
    // cout << board.get_orbs_num(0, 0) << endl;
    // cout << board.get_cell_color(0, 0) << endl;
    // board.print_current_board(0, 0, 0);

        position god = God_choose(board, player);
        index[0] = god.x;
        index[1] = god.y;


}